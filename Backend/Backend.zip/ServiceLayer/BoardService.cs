﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IntroSE.Kanban.Backend.BusinessLayer;


namespace IntroSE.Kanban.Backend.ServiceLayer
{
    public class BoardService //public for testing
    {


        /// <summary>
        /// Adds a board to the specific user.
        /// </summary>
        /// <param name="email">Email of the user. Must be logged in</param>
        /// <param name="name">The name of the new board</param>
        /// <returns>A response object. The response should contain a error message in case of an error</returns>
        public Response AddBoard(UserController uc, string email, string name)
        {
            try
            {
                BusinessLayer.User tempUser = uc.GetUser(email);
                tempUser.AddBoard(name);
                return new Response();
            }
            catch (Exception e)
            {
                return new Response(e.Message);
            }

        }


        /// <summary>
        /// Removes a board to the specific user.
        /// </summary>
        /// <param name="email">Email of the user. Must be logged in</param>
        /// <param name="name">The name of the board</param>
        /// <returns>A response object. The response should contain a error message in case of an error</returns>
        public Response RemoveBoard(UserController uc, string email, string name)
        {
            try
            {
                BusinessLayer.User tempUser = uc.GetUser(email);
                tempUser.RemoveBoard(name);
                return new Response();
            }
            catch (Exception e)
            {
                return new Response(e.Message);
            }

        }
    }
}






