﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.Reflection;
using log4net.Config;
using System.IO;

namespace IntroSE.Kanban.Backend.BusinessLayer
{
    /*
`   The main Task class
    Contains all methods for performing Task's actions.
    */
    /// <summary>
    /// The main Task class.
    /// Contains all methods for performing Task's functions.
    /// </summary>
    /// <remarks>
    /// This class represnt the task , and allow to update the title , decription and the due date of the specific task
    /// </remarks>

    public class Task //public for testing
    {
        public int id;
        public readonly DateTime creationTime;
        public string title;
        public string description;
        public DateTime dueDate;

        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public Task(string title, string description, DateTime dueDate, int id)
        {
            this.id = id;
            if (ValidTitle(title))
                this.title = title;
            else
            {
                log.Error($"The title {title} is not valid");
                throw new ArgumentException("title not valid");
            }

            if (ValidDescription(description))
                this.title = title;
            else
            {
                log.Error($"The description {description} is not valid");
                throw new ArgumentException("description not valid");
            }
            DateTime now = DateTime.Now;
            if (dueDate < now) {
                log.Error($"The due date {dueDate} is not valid");
                throw new ArgumentException("can't set due date that in the past");
            }
            this.dueDate = dueDate;
            this.creationTime = DateTime.Now;
            log.Info($"Task  + {this.id}  created: creation time- {this.creationTime },title- {this.title },description- {this.description },dueDate- {this.dueDate }");
        }


        /// <summary>
        /// Get id of Task
        /// </summary>
        /// <returns>The id of Task</returns>
        public int GetId()
        {
            return this.id;
        }


        /// <summary>
        /// Check if the title is valid
        /// </summary>
        /// /// <param name="title">the title to check if valid</param>
        /// <returns>true if valid , false else</returns>
        private bool ValidTitle(string title)
        {
            if (title != null & title.Length > 0 & title.Length < 51)
            {
                log.Debug($"Return true when check {title} is valid");
                return true;
            }
            else
            {
                log.Debug($"Return false when check {title} is valid");
                return false;
            }
        }


        /// <summary>
        /// Check if the description is valid
        /// </summary>
        /// /// <param name="description">the description to check if valid</param>
        /// <returns>true if valid , false else</returns>
        private bool ValidDescription(string description)
        {
            if (description != null & description.Length <= 300)
            {
                log.Debug($"Return true when check {description} is valid");
                return true;
            }
            else
            {
                log.Debug($"Return false when check {description} is valid");
                return false;
            }
        }


        /// <summary>
        /// Set new title for the task
        /// </summary>
        /// /// <param name="newTitle">the new title of the task</param>
        /// <returns>set the new title , throw Exception if not</returns>
        public void SetTitle(string newTitle)
        {
            try
            {
                if (ValidTitle(newTitle))
                {
                    this.title = newTitle;
                }
                else
                {
                    throw new ArgumentException("New title input not valid");
                }
            }
            catch
            {
                log.Error($"Not able to set title as {newTitle}");
                throw new ArgumentException("Exception int tying to set new title");
            }

        }


        /// <summary>
        /// Set new description for the task
        /// </summary>
        /// /// <param name="newDescription">the new description of the task</param>
        /// <returns>set the new description , throw Exception if not</returns>
        public void SetDescription(string newDescription)
        {
            try
            {
                if (ValidDescription(newDescription))
                {
                    this.description = newDescription;
                }
                else
                {
                    log.Error($"Try to input not valid description ");
                    throw new ArgumentException("New description not valid");
                }
            }
            catch
            {
                log.Error($"Not able to set description as {newDescription}");
                throw new ArgumentException("Exception int tying to set new description");
            }

        }


        /// <summary>
        /// Set new DueDate for the task
        /// </summary>
        /// /// <param name="inputDate">the new DueDate of the task</param>
        /// <returns>set the new DueDate , throw Exception if not</returns>
        public void SetDueDate(DateTime inputDate)
        {
            try
            {
                this.dueDate = Convert.ToDateTime(inputDate);
            }
            catch
            {
                log.Error($"Not able to set due date as {inputDate}");
                throw new ArgumentException("new Date not valid");
            }
        }

    }
}
